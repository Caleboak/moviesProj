package entities

type DbMovie struct {
	Movies []Movie
}
